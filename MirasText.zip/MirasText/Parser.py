with open('MirasText/MirasText_sample.txt', 'r', encoding='utf8') as file:

    for line in file:
        tokens = line.split('***')
        content = tokens[0]
        desc = tokens[1]
        keywords = tokens[2]
        title = tokens[3]
        website = tokens[4]
        url = tokens[5]

        print('Content : ' + content)
        print('Description : ' + desc)
        print('keywords : ' + keywords)
        print('title : ' + title)
        print('Website : ' + website)
        print('url : ' + url)
