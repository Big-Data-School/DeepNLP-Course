import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from keras.models import Sequential
from keras import layers
import matplotlib.pyplot as plt
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
import numpy as np

data_path_dict = {'yelp': 'Text_Classification_Keras/data/yelp_labelled.txt',
                  'imdb': 'Text_Classification_Keras/data/imdb_labelled.txt',
                  'amazon': 'Text_Classification_Keras/data/amazon_cells_labelled.txt'}


df_list = []
for source, datapath in data_path_dict.items():
    df = pd.read_csv(datapath, names=['sentence', 'label'], sep='\t')
    df['source'] = source
    df_list.append(df)

df = pd.concat(df_list)
print(df.iloc[0])

df_yelp = df[df['source'] == 'yelp']
sentences = df_yelp['sentence'].values
y = df_yelp['label'].values

sentences_train, sentences_test, y_train, y_test = train_test_split(sentences, y, test_size=0.25,
                                                                    random_state=1000)

vectorizer = CountVectorizer()
vectorizer.fit(sentences_train)

x_train = vectorizer.transform(sentences_train)
x_test = vectorizer.transform(sentences_test)

x_train.shape

input_dim = x_train.shape[1]
model = Sequential()
model.add(layers.Dense(10, input_dim=input_dim, activation='relu'))
model.add(layers.Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy',
              optimizer='adam',
              metrics=['accuracy'])

model.summary()


history = model.fit(x_train, y_train, epochs=100, verbose=False,
                    validation_data = (x_test, y_test), batch_size = 10)

loss, accuracy = model.evaluate(x_train, y_train, verbose = False)
print("Training process Accuracy: {:.4f}".format(accuracy))

loss, accuracy = model.evaluate(x_test, y_test, verbose = False)
print("Testing process Accuracy: {:.4f}".format(accuracy))

tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(sentences_train)

x_train = tokenizer.texts_to_sequences(sentences_train)
x_test = tokenizer.texts_to_sequences(sentences_test)

vocab_size = len(tokenizer.word_index) + 1  # Adding 1 because of reserved 0 index

print(sentences_train[2])
print(x_train[2])

for word in ['the', 'all', 'happy', 'great']:
    print('{}: {}'.format(word, tokenizer.word_index[word]))

maxlen = 100

x_train = pad_sequences(x_train, padding='post', maxlen = maxlen)
x_test = pad_sequences(x_test, padding='post', maxlen = maxlen)

print(x_train[2, :])

model = Sequential()
embedding_dim = 50
numpy_matrix = np.random.rand(1747,50)
model.add(layers.Embedding(vocab_size, embedding_dim,
                           weights=[numpy_matrix],
                           input_length=maxlen,
                           trainable=True))
model.add(layers.GlobalMaxPool1D())
model.add(layers.Dense(10, activation='relu'))
model.add(layers.Dense(1, activation='sigmoid'))
model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])
model.summary()
history = model.fit(x_train, y_train,
                    epochs=50,
                    verbose=False,
                    validation_data=(x_test, y_test),
                    batch_size=10)

loss, accuracy = model.evaluate(x_train, y_train, verbose=False)
print("Training Accuracy: {:.4f}".format(accuracy))
loss, accuracy = model.evaluate(x_test, y_test, verbose=False)
print("Testing Accuracy:  {:.4f}".format(accuracy))