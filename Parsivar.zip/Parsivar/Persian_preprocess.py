text = "روز 8 مردادماه، سالروز تولد شیخ اشراق شهاب الدین سهروردی است ."
from parsivar import Normalizer
norm = Normalizer()

print(norm.normalize(text))

norm = Normalizer(statistical_space_correction=True)
print(norm.normalize(text))

text2 = "پنجمین سمینار زمستانه علوم کامپیوتر دانشگاه صنعتی شریف در 12 و 13 دی 1398 برگزار شد. این رویداد با استقبال جمع کثیری از علاقه مندان روبرو شد"
norm = Normalizer(date_normalizing_needed=True)
print(norm.normalize(text2))

text3 = "dirooz asman abri bood"
norm = Normalizer(pinglish_conversion_needed=True)
print(norm.normalize(text3))

from parsivar import Tokenizer
norm = Normalizer()
token = Tokenizer()
process = token.tokenize_sentences(norm.normalize(text2))

print(process)

words = token.tokenize_words(norm.normalize(text2))
print(words)

from parsivar import FindStems
stemmer = FindStems()
print(stemmer.convert_to_stem("بخواهیم"))
print(stemmer.convert_to_stem("بدانیم"))
print(stemmer.convert_to_stem("دانشجویان"))

from parsivar import POSTagger
tagger = POSTagger(tagging_model="wapiti")
tags = tagger.parse(token.tokenize_words("پنجمین سمینار زمستانه علوم کامپیوتر دانشگاه صنعتی شریف در 12 و 13 دی 1398 برگزار شد"))
print(tags)

from parsivar import FindChunks
chunker = FindChunks()
chunks = chunker.chunk_sentence(tags)
print(chunker.convert_nestedtree2rawstring(chunks))

from parsivar import SpellCheck
spell_checker = SpellCheck()
process = spell_checker.spell_corrector("خادمان در حرم مشغول فعالیت هستند")
